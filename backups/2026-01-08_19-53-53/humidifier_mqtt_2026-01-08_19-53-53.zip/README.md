# Humidifier MQTT (ESP32)

Прошивка для ESP32: управляет реле увлажнителя по влажности из MQTT и уставке (setpoint) из MQTT.
Есть минимальная веб-страница настройки (Wi‑Fi/MQTT/топики) и captive portal в режиме точки доступа, если Wi‑Fi не настроен или не подключился.

## 1) Сборка / прошивка

Требуется PlatformIO.

- Сборка: `pio run -e esp32dev`
- Прошивка: `pio run -e esp32dev -t upload`
- Монитор порта: `pio device monitor -b 115200`

Проект: [humidifier_mqtt](humidifier_mqtt)

## 2) Веб-настройка

Если Wi‑Fi не настроен/не подключился:

- ESP32 поднимает AP: SSID `Humidifier-Setup`, пароль `12345678`
- Откройте `http://192.168.4.1/` и заполните форму

Если Wi‑Fi подключился:

- Откройте в браузере IP устройства (показывается в Serial): `http://<ip>/`

## 3) MQTT-топики (по умолчанию)

Есть понятие **Base topic** (задаётся в веб-форме). Если не задать — будет `humidifier/<deviceId>`.

Прошивка публикует:

- `<base>/status/online` = `1` (online) / `0` (LWT, retain)
- `<base>/state/enabled` = `1` / `0` (retain)
- `<base>/state/relay` = `ON` / `OFF` (retain)
- `<base>/state/setpoint` = число (retain)
- `<base>/state/humidity` = число (retain, когда известно)
- `<base>/state/humidity_age_ms` = миллисекунды с последнего сообщения влажности (retain)

Прошивка **подписывается** на (задаётся в веб-форме):

- `External humidity topic` — входящая влажность (%RH)
- `Setpoint topic` — уставка влажности (%RH)
- `Enable topic` — включение/выключение системы

Формат команд:

- Enable: `1/0`, `ON/OFF`, `true/false`
- Setpoint: число (`45`, `45.5`, `45,5`)
- Humidity: число

## 4) Ограничение чтения влажности (5 минут)

Параметр `Humidity min interval` задаёт, как часто прошивка **разрешает обновлять** внутреннее значение влажности.
По умолчанию 300 секунд (5 минут).

Если датчик недоступен/не присылает данные — прошивка **не сбрасывает** текущую влажность.
Если влажность ещё ни разу не была получена — реле держится **выключенным** (безопасный режим).

## 5) Реле и пины

По умолчанию:

- `Relay pin = GPIO23`
- `Relay inverted = 1` (включение реле уровнем LOW)

Рекомендация на перспективу:

- Под будущий внутренний датчик влажности лучше планировать I2C и оставить GPIO21 (SDA) + GPIO22 (SCL).
- GPIO0/2/12/15 лучше избегать под реле (strap-пины, могут мешать загрузке).

## 6) Примеры mosquitto

```bash
mosquitto_pub -h <broker> -t "<setpoint_topic>" -m "45"
mosquitto_pub -h <broker> -t "<enable_topic>" -m "ON"
mosquitto_pub -h <broker> -t "<enable_topic>" -m "OFF"
mosquitto_sub -h <broker> -t "<base>/#" -v
```
